# Development Environment
The following document provides some information to setup the solution.

# Technology Documentation
## Backend technologies
- Keycloak Spring Boot Security Adapter: `https://www.keycloak.org/docs/latest/securing_apps/index.html#_spring_security_adapter`
- Spring Boot Security
- Spring Data

## Frontend technologies
- EclipseSource JSON Forms: `https://jsonforms.io/docs/getting-started`
- React redux: `https://redux.js.org/basics/usage-with-react`
- React redux saga: `https://redux-saga.js.org/`
- React material-ui: `https://material-ui.com/`

## Import Project into Eclipse
1. Start Eclipse
2. Select `File\Import...`
3. Select `General\Existing Projects into Workspace`
4. Select directory of source code ans press finish

## Running local Keycloak server for development
1. Running: `docker run -e KEYCLOAK_USER=admin -e TZ=Europe\Berlin -e KEYCLOAK_PASSWORD=admin -p 8180:8080 -p 9990:9990 jboss/keycloak`
          - ensure that TZ variable is set to right timezone, otherwise you will receive an error `token 
2. Browser: `http://127.0.0.1:8180/auth/`

## Creating Client ID in Keycloak
1. Browser: `http://127.0.0.1:8180/auth/`
2. Select `Open Adminstation Console`
3. Login using the following credentials 
    - username: `admin`
    - password: `admin`
4. Open tab `Configure/Clients`
5. Select `Create`button
6. `Add Client` with the following fields
    - Client ID: `devision-profile`
    - Client Protocol: `openid-connect`
    - Access Type: `confidencial`
7. Select `Save`button
8. Provide the following information to `Clients>>devision-profile` form:
     - Validation redirect URLs: `http://localhost:8080/*`
     - Web Origins: `http://localhost:8080/*`
9. Select `Save`button
10. Select Tab `Credentials` and copy `Secret`to Spring Boot properties file `src\main\resources\application.properties` to property `keycloak.credentials.secret`

## Configure `user` Role in Keycloak
1. Browser: `http://127.0.0.1:8180/auth/`
2. Select `Open Adminstation Console`
3. Login using the following credentials 
    - username: `admin`
    - password: `admin`
4. Select `Configure/Roles`
5. Create new Role by selecting `Add Role`and type in the following information:
       - Role Name: `user`
       - Composite Roles: ON
6. Select Combo Box `Client Roles` with value `master-realm`
7. Select `view-users` in list `Available Rules`  and press `Add selected>>` button


## Configure sample user `alice` in Keycloak
1. Browser: `http://127.0.0.1:8180/auth/`
2. Select `Open Adminstation Console`
3. Login using the following credentials 
    - username: `admin`
    - password: `admin`

4. Select `Manage/Users` and press `Add user`
5. Input the following fields
          - username: alice
6. Select `Save`
7. Select tab `Credentials` and type in the following values
     -  New Password: `alice`
     -  Temporary: OFF
8. Press `Reset password` button and confirm
9. Select tab `Role Mappings` and select previously created Role `user` by pressing `Add selected>>`

## Building and running the solution using maven (also for CI/CD integration)
1. Create build: `mvn package`
2. Run solution: `mvn springboot:run`
3. Open browser at url: `http://localhost:8080`


## Development of React frontend
1. Open directoy: `src/main/app`
2. (Optional)install npm dependencies once: `npm install`
3. start react development server: `npm start`
4. open browser at: `http://localhost:3000`


## Development of Spring Boot backend service using Postman
1. Open Postman `https://www.getpostman.com/`
2. Import Collection by selecting `File\Import`
3. Drag and drop file from project location `etc/devision-profile.json.postman_collection` to Postman
3. Select test `Load Profile`
4. Select tab `Authorization` and select `Type: OAuth2.0`
5. Click Button `Get New Access Token` with the following fields:
          - Grant Type: Authorization Code
          - Callback URL: http://localhost:8080
          - Auth URL: http://localhost:8180/auth/realms/master/protocol/openid-connect/auth
          - Access Token URL: http://localhost:8180/auth/realms/master/protocol/openid-connect/token
          - Client ID: devision-profile
          - Client Secret: see `Creating Client ID in Keycloak` for details
6. Press `Use Token` button
7. Press `Preview Request` button to copy token to HTTP header
8. Press `Send` button to call Spring Boot backend service






