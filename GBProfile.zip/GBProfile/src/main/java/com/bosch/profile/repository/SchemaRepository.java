package com.bosch.profile.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository("schemaRepository")
public interface SchemaRepository extends CrudRepository<Schema, String>{
} 
