package com.bosch.profile.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.bosch.profile.repository.FormMapping;
import com.bosch.profile.repository.FormMappingRepository;
import com.bosch.profile.service.KeycloakProfileService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * This controller provides a REST API to fetch json schema and json form
 * templates from a SQL database.
 * 
 * @author BFA1SZH
 *
 */
@RestController
public class FormController {

	/** repository containing the json schema and the format templates */
	@Autowired
	private FormMappingRepository repository;

	/** access to Keycloak Admin API */
	@Autowired
	private KeycloakProfileService profile;

	/** json mapper */
	private final ObjectMapper mapper = new ObjectMapper();

	/** logging */
	private final Logger log = LoggerFactory.getLogger(FormController.class.getName());

	/**
	 * fetches localized UI layout, schema and data for the given user from the the
	 * backend.
	 * 
	 * @param principal user that is used to fetch data for
	 * @param lang      ISO 639 locale, default: en-US
	 * @param clientId  OIDC client id
	 * @return JSON representation
	 */
	@GetMapping(value = "/api/v1/load", produces = "application/json")
	@ResponseBody
	public String load(Principal principal,
			@RequestParam(name = "lang", required = false, defaultValue = "en-US") String lang,
			@RequestParam(name = "client_id", required = false, defaultValue = "12345") String clientId) {

		log.info("Request from " + principal.getName());
		String str = "";
		// TODO: also include 'lang' in search query
		Optional<FormMapping> mapping = this.repository.findById(clientId);
		if (!mapping.isPresent())
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "client_id not found");

		ObjectNode result = mapper.createObjectNode();
		try {
			JsonNode data = this.profile.loadUser(principal);
			JsonNode schema = this.mapper.readTree(mapping.get().getSchema().getSchema());
			JsonNode layout = this.mapper.readTree(mapping.get().getLayout());
			result.set("schema", schema);
			result.set("layout", layout);
			result.set("data", data);
			str = this.mapper.writeValueAsString(result);
		} catch (IOException e) {
			this.log.error("Cannot create response", e);
		}

		return str;
	}
}
