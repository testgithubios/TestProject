package com.bosch.profile.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

// TODO: add finder for clientId, lang
@Repository("formRepository")
public interface FormMappingRepository extends CrudRepository<FormMapping, String>{
} 
