package com.bosch.profile.repository;

import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;

import java.io.Serializable;

import javax.persistence.Column;;

@Entity
@Table(name = "schema")
public class Schema implements Serializable{   

    private static final long serialVersionUID = 132132131L;

    @Id
    @Column(name="schema_id")
    private String schemaId;

    @Column(name="schema", length=4096)
    private String schema;

    public Schema(){

    }

    public Schema(String schemaId, String schema){
        this.schemaId = schemaId;
        this.schema = schema;        
    }

    public String getSchemaId(){
        return this.schemaId;
    }

    public String getSchema(){
        return this.schema;
    }
}

