package com.bosch.profile.repository;

import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name = "form_mapping")
public class FormMapping implements Serializable{   
    private static final long serialVersionUID = 42342342L;

    @Id
    @Column(name="client_id")
    private String clientId;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "schema_id")
    private Schema schema;

    @Column(name="locale")
    private String locale;

    @Column(name="layout", length=4096)
    private String layout;

    public FormMapping(){

    }

    public FormMapping(String clientId, Schema schema, String locale, String layout){
        this.clientId = clientId;
        this.schema = schema;
        this.locale = locale;
        this.layout = layout;        
    }

    public String getClientId(){
        return this.clientId;
    }

    public Schema getSchema(){
        return this.schema;
    }

    public String getLayout(){
        return this.layout;
    }

    public String getLocale(){
        return this.locale;
    }    
}

