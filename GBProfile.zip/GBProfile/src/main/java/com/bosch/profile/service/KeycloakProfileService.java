package com.bosch.profile.service;

import java.io.IOException;
import java.security.Principal;

import org.keycloak.adapters.springsecurity.client.KeycloakRestTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bosch.profile.controller.FormController;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * Profile service that uses the keycloak Admin API to manage user attributes.
 * 
 * @author BFA1SZH
 *
 */
@Service
public class KeycloakProfileService {

	/** URL to keycloak server */
	// TODO: read value application.properties
	private final String KEYCLOAK_URL = "http://localhost:8180/auth/admin/realms/master/users/";

	/** logging */
	private final Logger log = LoggerFactory.getLogger(FormController.class.getName());

	/** json mapper */
	private final ObjectMapper mapper = new ObjectMapper();

	/** rest client */
	@Autowired
	private KeycloakRestTemplate template;

	/**
	 * fetches user information from keycloak server Documentation:
	 * https://www.keycloak.org/docs-api/6.0/rest-api/index.html#_users_resource
	 * 
	 * @param user security principal
	 * @return
	 */
	public JsonNode loadUser(Principal user) throws IOException {
		if (user == null)
			throw new IllegalArgumentException("argument 'user' cannot be null");

		log.info("Loading attributes of user " + user.getName());
		String result = this.template.getForObject(KEYCLOAK_URL + user.getName(), String.class);
		log.info(result);
		return this.convertKeycloakToSchema(result);
	}

	/**
	 * converts a Keycloak string to a JSON that is mapable to the forms
	 * 
	 * @param data
	 * @return
	 * @throws IOException
	 */
	private JsonNode convertKeycloakToSchema(String data) throws IOException {
		ObjectNode result = mapper.createObjectNode();

		JsonNode source = null;
		source = this.mapper.readTree(data);

		// map standard Keycloak attributes
		result.put("id", source.get("id").asText());
		result.put("createdTimestamp", source.get("createdTimestamp").asLong());
		result.put("username", source.get("username").asText());
		
		result.put("firstName", source.get("firstName")!= null ? source.get("firstName").asText(): "");
		result.put("lastName", source.get("lastName") != null ? source.get("lastName").asText() : "");
		result.put("email", source.get("email")!= null ? source.get("email").asText(): "");
		
		// TODO add custom attributes here
		return result;
	}
}
