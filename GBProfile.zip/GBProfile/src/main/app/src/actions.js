  
  /**
   * define all action names here
   */
  export const ActionIds = {
    LOAD_REGISTRATION: "LOAD_REGISTRATION",
    PREV_REGISTRATION: "PREV_REGISTRATION",
    FINISH_REGISTRATION: "FINISH_REGISTRATION"
  }
  
  export const LoadRegistrationAction = () => ({
    type: ActionIds.LOAD_REGISTRATION
  })

  export const PrevRegistrationAction = () => ({
    type: ActionIds.PREV_REGISTRATION,    
  })

  export const FinishRegistrationAction = () => ({
    type: ActionIds.FINISH_REGISTRATION    
  })
