import { connect } from 'react-redux';
import { JsonForms } from '@jsonforms/react';
import React from 'react';
import { Dispatch } from 'redux';
import Grid from "@material-ui/core/Grid";
import Button from "@material-ui/core/Button";
import withStyles, { WithStyles } from "@material-ui/core/styles/withStyles";
import {getData, JsonFormsState} from '@jsonforms/core';
import './App.css';
import createStyles from "@material-ui/core/styles/createStyles";
import {LoadRegistrationAction, PrevRegistrationAction,FinishRegistrationAction} from './actions';
import { TextField } from '@material-ui/core';


const styles = createStyles({
  container: {
    padding: '1em'
  },
  title: {
    textAlign: 'center',
    padding: '0.25em'
  },
  dataContent: {
    display: 'flex',
    justifyContent: 'center',
    borderRadius: '0.25em',
    backgroundColor: '#cecece',
  },
  demoform: {
    margin: 'auto'
  }
});

export interface AppProps extends WithStyles<typeof styles> {
  dataAsString: string;
  username:string;
  password:string;
  loadProfile: ()=> void;
  handlePreviousButton: () => void;
  handleFinishButton: () => void;
}

class App extends React.Component<AppProps, any> {
  username: string = "alice";
  password: string = "alice";

  /**
   * Called by react framework after component has been initialized.
   * Loads profile from backend.
   */
  componentDidMount(){       
    this.props.loadProfile();
  }

  render() {    
    return (
      <div>
        <div className="App">
          <header className="App-header">
            <img src="logo.png" className="App-logo" alt="logo"/>
          </header>
        </div>

        <Grid container justify={'center'} spacing={24} className={this.props.classes.container}>
          <Grid item sm={12}>
            <form>
            <label>Login</label>
            <TextField id="username" label="Name" value={this.username} margin="normal" variant="outlined" />
            <TextField id="password" label="Password" value={this.password} margin="normal" variant="outlined" />
            </form>
          </Grid>
          <Grid item sm={12}>
            <div className={this.props.classes.demoform}>
              <JsonForms/>
            </div>
          </Grid>
          <Grid item sm={12}>
            <Button color="primary" onClick={this.props.handlePreviousButton}>Previous</Button>
            <Button color="primary" onClick={this.props.handleFinishButton}>Finish</Button>
          </Grid>
        </Grid>
      </div>
    );
  }
}

const mapStateToProps = (state: JsonFormsState) => {
  return { dataAsString: JSON.stringify(getData(state), null, 2) }
};

const mapDispatchToProps = (dispatch: Dispatch, props:any) => ({
  loadProfile: () => dispatch(LoadRegistrationAction()),
  handlePreviousButton: () => dispatch(PrevRegistrationAction()),
  handleFinishButton: () => dispatch(FinishRegistrationAction())
});

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(App));

