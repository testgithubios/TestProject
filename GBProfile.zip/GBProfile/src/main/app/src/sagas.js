import { call, put, takeLatest, select } from 'redux-saga/effects'
import {ApiLoad} from './Api'
import {ActionIds} from './actions'
import { Actions} from '@jsonforms/core';
import {getData, JsonFormsState} from '@jsonforms/core';

/**
 * calls java backend system asynchronously to fetch user data
 */
function* loadRegistration(action) {
   try {      
      const result = yield call(ApiLoad,"12345","en-US");
      yield put (Actions.init(result.response.data,result.response.schema,result.response.layout))      
   } catch (e) {
      console.error("Cannot user:%s", e.error)
   }
}

function* navigateToPrevRegistration(action) {
// TODO: JUST FOR DEBUGGING, PLEASE REPLACE
   try {      
      const result = yield call(ApiLoad,"12345","en-US");
      yield put (Actions.init(result.response.data,result.response.schema,result.response.layout))      
   } catch (e) {
      console.error("Cannot user:%s", e.error)
   }

}

function* finishRegistration(action) {
   const getJsonData = (state) => state.jsonforms.core.data;
   const data = yield select(getJsonData);
   yield console.info("Finish regitration: %s",JSON.stringify(data))
}

/**
 * main function to register all events
 */
function* mySaga() {
  yield takeLatest(ActionIds.LOAD_REGISTRATION, loadRegistration);
  yield takeLatest(ActionIds.PREV_REGISTRATION, navigateToPrevRegistration);
  yield takeLatest(ActionIds.FINISH_REGISTRATION, finishRegistration);
}

export default mySaga;
