# TODO list
The following list contains a list of open items
## CI/CD Pipeline integration
- create build pipeline using given maven pom
- integrate unit testing  with code coverage (e.g. covertura, etc.)
- integrate sonarcube
- integrate checkstyle and PMD

## Spring Boot Backend Service
- create JPA SQL query that considers client_id and language (effort: low)
- add custom attributes  mapping in KeycloakProfileService (effort: low)
- implement saveUser method in KeycloakProfileService (effort: medium)
- implement save endpoint in FormController (effort: medium)
- add unit tests for KEycloakPRofileService (effoirt: medium)
- add unit tests for FormController (effort: medium)

## React frontend service
- add router to support client_id and lang URL attributes (effort: medium)
- update saga to use these attributes in KeycloakProfileService (effort: high)
- integrate solution with existing Keycloak Dev Sandbox (effort: high)
- integrate solution as post-registration in CIAM Dev (effort: high)
- end-to-end testing with backens (effort: high)
